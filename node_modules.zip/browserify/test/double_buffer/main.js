var implicit = require('./implicit.js');
var explicit = require('./explicit.js');

t.equal(implicit, explicit);
